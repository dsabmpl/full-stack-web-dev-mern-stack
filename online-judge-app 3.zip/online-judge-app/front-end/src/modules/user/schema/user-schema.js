// Schema Define. = Fields + Constraints
import {z} from 'zod';
export const loginSchema = z.object({
    email : z.string({required_error:'Email is Required'}).
    trim().toLowerCase().email('Enter a Valid Email Address'),
    password: z.string({required_error:'Password is Required'})
    .min(8, "Password can't be less than 8 Characters")
    .max(25, "Password Can't be more than 25 characters")
});

export const loginDefaultValues = {
    email : "",
    password :""
}