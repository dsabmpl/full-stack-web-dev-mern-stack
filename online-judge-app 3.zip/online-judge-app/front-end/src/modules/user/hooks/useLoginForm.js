import {useForm} from 'react-hook-form';
import { loginDefaultValues, loginSchema } from '../schema/user-schema';
import {zodResolver} from '@hookform/resolvers/zod';
import { doLogin } from '../api/user-api';
export const useLoginForm = ()=>{
    const form = useForm({
        defaultValues : loginDefaultValues,
        resolver: zodResolver(loginSchema)
    });
    const onSubmit = form.handleSubmit(async (values)=>{
        console.log('Values ', values);
        alert("Login SuccessFully");
        try{
        const data = await doLogin(values);
        console.log('Data is ', data);
        }
        catch(err){
            console.log('Login BackEnd Call Fails ', err);
        }
    })
    return {form, onSubmit};
}