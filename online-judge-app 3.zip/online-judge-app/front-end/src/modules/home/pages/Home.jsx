import { Button, Card, Flex, Heading, Separator, Text } from "@radix-ui/themes";
import { AppRoutes } from "../../../shared/routes/AppRoutes";

export const Home = () => {
  const URL = "https://live.staticflickr.com/6169/6203286732_8048b00ac3_b.jpg";
  return (
    <div
      style={{
        position: "relative",
        height: "100vh",
        width: "100%",
        overflow: "hidden",
      }}
    >
      <img
        src={URL}
        alt="Coding Contest"
        style={{
          width: "100%",
          height: "100%",
          objectFit: "cover",
          filter: "brightness(0.50)",
        }}
      />
      <Flex
        direction="column"
        align="center"
        justify="center"
        style={{
          position: "absolute",
          inset: 0,
          color: "white",
          textAlign: "center",
          gap: "1rem",
        }}
      >
        <Card size="4">
          <Heading>Welcome to my Coding Judge</Heading>
          <Text color="red" size="3">
            Practice DSA Here
          </Text>

          <Separator />
        </Card>
      </Flex>
    </div>
  );
};
