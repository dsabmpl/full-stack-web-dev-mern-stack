import { Flex, Heading, Separator, Text, Button } from "@radix-ui/themes";
import { Link } from "react-router-dom";
export const Header = () => {
  return (
    <Flex align="center" justify="center" gap="3" mt="3">
      <Button color="red" variant="soft" asChild>
        <Link to="/">Home</Link>
      </Button>
      <Button color="orange" variant="soft" asChild>
        <Link to="/login">Login</Link>
      </Button>
      <Button color="cyan" variant="soft" asChild>
        <Link to="/register">Register</Link>
      </Button>
    </Flex>
  );
};
