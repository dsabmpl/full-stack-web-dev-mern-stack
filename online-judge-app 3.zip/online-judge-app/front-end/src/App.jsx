import { Home } from "./modules/home/pages/Home";
import { Footer } from "./shared/components/Footer";
import { Header } from "./shared/components/Header";
import { AppRoutes } from "./shared/routes/AppRoutes";

const App = () => {
  return (
    <>
      <Header />
      <AppRoutes />
      <Footer />
    </>
  );
};
export default App;
