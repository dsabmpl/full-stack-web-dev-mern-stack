import { Card, Heading, TextField, Text, Flex, Button } from "@radix-ui/themes";
import { useLoginForm } from "../hooks/useLoginForm";

export const Login = () => {
  const { form, onSubmit } = useLoginForm();
  const {
    register,
    formState: { errors },
  } = form;
  return (
    <div>
      <Card size="4" style={{ maxWidth: 500, marginInline: "auto" }}>
        <Heading>Login </Heading>
        <form
          onSubmit={(event) => {
            event.preventDefault();
            onSubmit();
          }}
        >
          <Flex direction="column" gap="3" mt="3">
            <div>
              <Text as="label" size="2" color="orange">
                Email
              </Text>
              <TextField.Root
                type="email"
                {...register("email")}
                placeholder="Type Email Here"
              ></TextField.Root>
              {errors.email && (
                <Text size="2" color="red">
                  {errors.email.message}
                </Text>
              )}
            </div>
            <div>
              <Text as="label" size="2" color="orange">
                Password
              </Text>
              <TextField.Root
                type="password"
                {...register("password")}
                placeholder="Type Password Here"
              />
              {errors.password && (
                <Text size="2" color="red">
                  {errors.password.message}
                </Text>
              )}
            </div>
            <div>
              <Button variant="soft" color="cyan">
                Login
              </Button>
            </div>
          </Flex>
        </form>
      </Card>
    </div>
  );
};
