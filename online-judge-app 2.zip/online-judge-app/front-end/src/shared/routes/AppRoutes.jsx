import { Route, Routes } from "react-router-dom";
import { Login } from "../../modules/user/pages/Login";
import { Register } from "../../modules/user/pages/Register";
import { Home } from "../../modules/home/pages/Home";

export const AppRoutes = () => {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="login" element={<Login />} />
      <Route path="register" element={<Register />} />
    </Routes>
  );
};
