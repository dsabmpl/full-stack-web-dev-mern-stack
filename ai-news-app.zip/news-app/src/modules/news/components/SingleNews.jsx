import { Button } from "@radix-ui/themes";
export const SingleNews = ({ article, doSummarize }) => {
  const showSummary = () => {
    doSummarize(article);
  };
  const speakSummary = () => {
    if (!article.summary) {
      return;
    }
    window.speechSynthesis.cancel();
    const obj = new SpeechSynthesisUtterance(article.summary);
    window.speechSynthesis.speak(obj);
  };
  return (
    <div style={{ textAlign: "center", padding: "10px" }}>
      <img
        src={article.urlToImage}
        style={{
          width: "80%",
          height: "500px",
          border: "2px solid green",
          borderRadius: "10px",
        }}
      />
      <p style={{ fontSize: "24px", fontWeight: "bold" }}>{article.title}</p>
      <div style={{ display: "flex", gap: 8, justifyContent: "center" }}>
        <p
          style={{ color: "white", backgroundColor: "black", fontSize: "14px" }}
        >
          {article.summary}
        </p>
        <Button onClick={showSummary} variant="classic">
          Summary
        </Button>

        <Button onClick={speakSummary} color="orange">
          Speak Summary
        </Button>
        <a href={article.url} target="_blank">
          Read More
        </a>
      </div>
    </div>
  );
};
