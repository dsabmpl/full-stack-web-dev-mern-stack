import axios from 'axios';
export const getNews = ()=>{
    return axios.get(import.meta.env.VITE_NEWS_URL);
}