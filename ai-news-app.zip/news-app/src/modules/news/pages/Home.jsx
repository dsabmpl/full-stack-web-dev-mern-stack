import { useEffect, useState } from "react";
import { Footer } from "../../../shared/components/Footer";
import { Header } from "../../../shared/components/Header";
import { SingleNews } from "../components/SingleNews";
import { getNews } from "../api/news-api";
import { Loader } from "lucide-react";
import { createGoogleGenerativeAI } from "@ai-sdk/google";
import { generateText } from "ai";
export const Home = () => {
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(true);

  const doSummary = async (article) => {
    console.log("AI Call...", article);
    // AIzaSyCeXXOEZ8QtTHslUVC1ttGBqnuc4220KLU
    const google = createGoogleGenerativeAI({
      apiKey: "AIzaSyCeXXOEZ8QtTHslUVC1ttGBqnuc4220KLU",
    });
    const { text } = await generateText({
      model: google("gemini-2.5-flash"),
      prompt: `Create a short , engaging 3 line sentence summary of this news article for a mobile short style news
      make it casual and easy to understand : Title :${article.title} Content:${
        article.description || article.content
      }
      Keep this news with in 50 words and make it sound natural for text to speech
      `,
    });
    console.log("Summary ", text);
    setArticles((prev) =>
      prev.map((a) =>
        a.url === article.url ? { ...a, summary: text } : { ...a }
      )
    );
  };

  const loadNews = async () => {
    const response = await getNews();
    console.log(response.data.articles);
    setLoading(false);
    setArticles(response.data.articles); // render News UI
  };
  useEffect(() => {
    loadNews();
  }, []);
  return (
    <>
      <Header />
      <div style={{ minHeight: "100vh" }}>
        {loading ? (
          <Loader />
        ) : (
          articles.map((article, index) => (
            <SingleNews doSummarize={doSummary} key={index} article={article} />
          ))
        )}
      </div>
      <Footer />
    </>
  );
};
