import { Home } from "./modules/news/pages/Home";

const App = () => {
  return <Home />;
};
export default App;
