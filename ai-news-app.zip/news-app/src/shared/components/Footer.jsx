export const Footer = () => {
  return (
    <footer>
      <hr />
      <div
        style={{
          textAlign: "center",
          padding: "20px",
          fontSize: "18px",
          color: "green",
        }}
      >
        <p>Powered By Brain Mentors</p>
      </div>
    </footer>
  );
};
