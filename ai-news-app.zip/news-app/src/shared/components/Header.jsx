import { Rocket } from "lucide-react";
export const Header = () => {
  const myStyle = {
    padding: "20px",
    textAlign: "center",
  };
  return (
    <header>
      <div style={myStyle}>
        <h1 style={{ color: "red" }}>
          <Rocket />
          &nbsp; AI Based News Summarizer
        </h1>
        <hr />
      </div>
    </header>
  );
};
