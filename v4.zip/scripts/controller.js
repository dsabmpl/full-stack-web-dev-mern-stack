// Glue b/w View and Model / Service
import { ToDoService } from "./service.js";
window.addEventListener('load', init);
function bindEvents(){
    document.querySelector('#add').addEventListener('click', addNewTask);
     document.querySelector('#delete').addEventListener('click', deleteForEver);
}
var fn;


function disableDeleteButton(){
    const deleteButton = document.querySelector('#delete');
    deleteButton.disabled = true;
}
function init(){
    disableDeleteButton();
    updateCount();
    bindEvents();
    fn = (function (){
    var count = 0;
    function autoIncrement(){
        count++;
        return count;
}
return autoIncrement;
})();
    document.querySelector('#id').innerText = fn();
}

function deleteForEver(){
    console.log('Delete all marked records');
     const tasks =  ToDoService.deleteTask();
   printAllTasks(tasks);

}

function printAllTasks(tasks){
    document.querySelector('#task-list').innerHTML = '';
    tasks.forEach(function(task){
        printTask(task);
    });
    updateCount();
    disableDeleteButton();

}

function addNewTask(){
    // read Fields
    const taskObject = readFields();
    ToDoService.addTask(taskObject);
    updateCount();
    printTask(taskObject);
    document.querySelector('#id').innerText = fn();
}
function updateCount(){
    document.querySelector('#total').innerText = ToDoService.totalTask();
    document.querySelector('#mark-total').innerText = ToDoService.countMarkTask();
    document.querySelector('#unmark-total').innerText = ToDoService.countUnMarkTask();
}
function printTask(taskObject){
    const tbody = document.querySelector('#task-list');
    // tr - table row --> td -->cell (table data)
    const tr = tbody.insertRow();
    for(let key in taskObject){
        if(key === 'isDeleted'){
            continue;
        }
        const td = tr.insertCell();
        td.innerText =  taskObject[key];
    }
    const cell = tr.insertCell();
    cell.appendChild(createIcon('fa-trash', toggleTask, taskObject.id));
    cell.appendChild(createIcon('fa-pen', edit, taskObject.id));
    //cell.innerText = 'delete edit';
    //cell.innerHTML = ' <i class="fa-solid fa-trash"></i> <i class="fa-solid fa-pen"></i>';
}
function createIcon(className, fn, id){
    const iTag = document.createElement('i'); 
    iTag.className = `icon fa-solid ${className}`;
    iTag.addEventListener('click', fn);
    iTag.setAttribute('task-id', id);
    return iTag;
}

function toggleTask(){
    const current = this; // current icon clicked 
    console.log('Toggle Task Call ', this);
    const id = this.getAttribute('task-id');
    const tr = current.parentNode.parentNode;
   // tr.className = 'red';
   tr.classList.toggle('red');
   ToDoService.toggle(id);
   updateCount();
    const deleteButton = document.querySelector('#delete');
    
   if(ToDoService.countMarkTask()>0){
    deleteButton.disabled = false;
   }
   else{
    deleteButton.disabled = true;
   }

}
function edit(){
     console.log('Edit Task Call ');
}
// <i class="fa-solid fa-trash"></i> <i class="fa-solid fa-pen"></i>
function readFields(){
    const fields = ['id', 'name', 'desc'];
    const taskObject = {}; // Object Literal
    for(let field of fields){
        if(field == 'id'){
            taskObject[field] = document.querySelector(`#${field}`).innerText ;
            continue;
        }
        taskObject[field] = document.querySelector(`#${field}`).value;
    }
    return taskObject;

    //console.log('Task object ', taskObject);
    // const id = document.querySelector('#id').value;
    // const name = document.querySelector('#name').value;
    // const desc = document.querySelector('#desc').value;
    //console.log('All Field data is ', id, name, desc);
}