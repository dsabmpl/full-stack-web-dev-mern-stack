// Service - Contains Business Logic eg. CRUD Logic
// const obj = {key:value, key:value}
import Task from './model.js';
export const ToDoService ={
    tasks:[],
    // addTask : function(){

    // }
    addTask(taskObject){
        const task = new Task(taskObject.id, taskObject.name, taskObject.desc);
        this.tasks.push(task);
    },
    totalTask(){
        return this.tasks.length;
    },
    deleteTask(){
         this.tasks = this.tasks.filter(function(task){
            return task.isDeleted !== true;
    });
    return this.tasks;
    },
    toggle(id){
        const taskObject = this.searchTask(id);
        if(taskObject){
            taskObject.isDeleted = !taskObject.isDeleted;
        }
    },
    searchTask(id){
       return this.tasks.find(function(task){
            return task.id == id;
        })
    },
    updateTask(){

    },
    countMarkTask(){
        const arr = this.tasks.filter(function(task){
            return task.isDeleted == true;    
        });
        return arr.length;
    },
    countUnMarkTask(){
        return this.tasks.length - this.countMarkTask();
    },
    sortTask(){

    }
}