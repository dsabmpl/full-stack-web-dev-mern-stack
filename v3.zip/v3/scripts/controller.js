// Glue b/w View and Model / Service
import { ToDoService } from "./service.js";
window.addEventListener('load', bindEvents);
function bindEvents(){
    document.querySelector('#add').addEventListener('click', addNewTask);
}
function addNewTask(){
    // read Fields
    const taskObject = readFields();
    ToDoService.addTask(taskObject);
    updateCount();
    printTask(taskObject);
}
function updateCount(){
    document.querySelector('#total').innerText = ToDoService.totalTask();
}
function printTask(taskObject){
    const tbody = document.querySelector('#task-list');
    // tr - table row --> td -->cell (table data)
    const tr = tbody.insertRow();
    for(let key in taskObject){
        const td = tr.insertCell();
        td.innerText =  taskObject[key];
    }
    const cell = tr.insertCell();
    cell.appendChild(createIcon('fa-trash', toggleTask));
    cell.appendChild(createIcon('fa-pen', edit));
    //cell.innerText = 'delete edit';
    //cell.innerHTML = ' <i class="fa-solid fa-trash"></i> <i class="fa-solid fa-pen"></i>';
}
function createIcon(className, fn){
    const iTag = document.createElement('i'); 
    iTag.className = `icon fa-solid ${className}`;
    iTag.addEventListener('click', fn);
    return iTag;
}

function toggleTask(){
    console.log('Toggle Task Call ');
}
function edit(){
     console.log('Edit Task Call ');
}
// <i class="fa-solid fa-trash"></i> <i class="fa-solid fa-pen"></i>
function readFields(){
    const fields = ['id', 'name', 'desc'];
    const taskObject = {}; // Object Literal
    for(let field of fields){
        taskObject[field] = document.querySelector(`#${field}`).value;
    }
    return taskObject;

    //console.log('Task object ', taskObject);
    // const id = document.querySelector('#id').value;
    // const name = document.querySelector('#name').value;
    // const desc = document.querySelector('#desc').value;
    //console.log('All Field data is ', id, name, desc);
}