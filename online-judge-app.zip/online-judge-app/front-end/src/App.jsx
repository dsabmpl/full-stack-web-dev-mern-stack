import { Home } from "./modules/home/pages/Home";

const App = () => {
  return <Home />;
};
export default App;
