import { Button, Card, Flex, Heading, Separator, Text } from "@radix-ui/themes";
import { AppRoutes } from "../../../shared/routes/AppRoutes";
import { Link } from "react-router-dom";
export const Home = () => {
  return (
    <Card size="4">
      <Heading>Welcome to my Coding Judge</Heading>
      <Text color="red" size="3">
        Practice DSA Here
      </Text>
      <Flex gap="3" mt="3">
        <Button color="orange" variant="soft" asChild>
          <Link to="/login">Login</Link>
        </Button>
        <Button color="cyan" variant="soft" asChild>
          <Link to="/register">Register</Link>
        </Button>

        <Separator />
        <AppRoutes />
      </Flex>
    </Card>
  );
};
