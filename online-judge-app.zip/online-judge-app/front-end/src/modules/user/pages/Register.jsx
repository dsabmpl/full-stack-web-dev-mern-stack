import { Heading } from "@radix-ui/themes";

export const Register = () => {
  return (
    <div>
      <Heading>Register Page...</Heading>
    </div>
  );
};
