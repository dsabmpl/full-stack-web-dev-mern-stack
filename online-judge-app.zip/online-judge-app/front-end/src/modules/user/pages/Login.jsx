import { Card, Heading, TextField, Text, Flex, Button } from "@radix-ui/themes";

export const Login = () => {
  return (
    <div>
      <Card size="4" style={{ maxWidth: 500, marginInline: "auto" }}>
        <Heading>Login </Heading>
        <form>
          <Flex direction="column" gap="3" mt="3">
            <div>
              <Text as="label" size="2" color="orange">
                Email
              </Text>
              <TextField.Root placeholder="Type Email Here"></TextField.Root>
            </div>
            <div>
              <Text as="label" size="2" color="orange">
                Password
              </Text>
              <TextField.Root placeholder="Type Password Here" />
            </div>
            <div>
              <Button variant="soft" color="cyan">
                Login
              </Button>
            </div>
          </Flex>
        </form>
      </Card>
    </div>
  );
};
