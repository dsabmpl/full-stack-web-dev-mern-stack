import express from 'express';
import dotenv from 'dotenv';
import chalk from 'chalk';
import { userRoutes } from './src/api/v1/routes/user/user-routes.js';
import { Error404 } from './src/utils/middlewares/404.js';
dotenv.config();
const app = express();
// app.use(middleware)
app.use(express.json());
app.use('/', userRoutes);
app.get('/health-check', (request, response)=>{
    response.send('Online Judge API Up and Running....');
});
app.use(Error404);
const server= app.listen(process.env.PORT || 7777,err=>{

    if(err){
        console.log(chalk.redBright.bold('Server Crash ....'), err);
    }
    else{
        console.log(chalk.bgGreenBright.blueBright.bold('Server Up and Running  '+process.env.APP_NAME), server.address().port);
    }
} )