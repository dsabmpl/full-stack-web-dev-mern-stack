import express from 'express';
import { doLogin, doRegister } from '../../../../controllers/user/user-controller.js';
export const userRoutes = express.Router();
userRoutes.post('/register', doRegister);
userRoutes.post('/login', doLogin);