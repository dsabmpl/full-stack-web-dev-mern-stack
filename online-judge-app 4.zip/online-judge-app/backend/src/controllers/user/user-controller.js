export const doRegister = (request, response)=>{
      const userInfo = request.body;
      console.log('UserInfo is ', userInfo);
      //response.send('Register....')
      response.status(200).json({message:'Register SuccessFully'});
}
export const doLogin = (request, response)=>{
    response.send('Login....')
}