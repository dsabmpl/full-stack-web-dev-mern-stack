// Service - Contains Business Logic eg. CRUD Logic
// const obj = {key:value, key:value}
import Task from './model.js';
export const ToDoService ={
    tasks:[],
    // addTask : function(){

    // }
    addTask(taskObject){
        const task = new Task(taskObject.id, taskObject.name, taskObject.desc);
        this.tasks.push(task);
    },
    totalTask(){
        return this.tasks.length;
    },
    deleteTask(){

    },
    searchTask(){

    },
    updateTask(){

    },
    countMarkTask(){

    },
    countUnMarkTask(){

    },
    sortTask(){

    }
}