// Glue b/w View and Model / Service
import { ToDoService } from "./service.js";
window.addEventListener("load", bindEvents);
function bindEvents() {
  document.querySelector("#add").addEventListener("click", addNewTask);
}
function addNewTask() {
  // read Fields
  const taskObject = readFields();
  ToDoService.addTask(taskObject);
  updateCount();
  printTask(taskObject);
}
function updateCount() {
  document.querySelector("#total").innerText = ToDoService.totalTask();
}
function printTask(taskObject) {
  /*
     <tr
                      class="group hover:bg-gradient-to-r hover:from-blue-50 hover:via-purple-50 hover:to-pink-50 transition-all duration-300 transform hover:scale-[1.02] hover:shadow-lg"
                    >
                      <td
                        class="px-6 py-5 border-r border-gray-200 font-bold text-gray-800 group-hover:text-blue-600 transition-colors duration-300"
                      >
                        <span
                          class="bg-gradient-to-r from-blue-500 to-purple-500 text-white px-3 py-1 rounded-full text-xs font-black"
                          >1</span
                        >
                      </td>
                      <td
                        class="px-6 py-5 border-r border-gray-200 font-semibold text-gray-800 group-hover:text-purple-600 transition-colors duration-300"
                      >
                        Sample Task
                      </td>
                      <td
                        class="px-6 py-5 border-r border-gray-200 text-gray-600 group-hover:text-gray-800 transition-colors duration-300"
                      >
                        Sample Description for the task
                      </td>
                      <td class="px-6 py-5 text-center">
                        <div class="flex justify-center space-x-3">
                          <button
                            class="icon group/btn p-2 bg-gradient-to-r from-blue-500 to-indigo-500 text-white rounded-xl shadow-lg transform transition-all duration-300 hover:scale-110 hover:shadow-xl hover:-translate-y-1"
                          >
                            <i
                              class="fas fa-edit text-sm group-hover/btn:animate-pulse"
                            ></i>
                          </button>
                          <button
                            class="icon group/btn p-2 bg-gradient-to-r from-red-500 to-pink-500 text-white rounded-xl shadow-lg transform transition-all duration-300 hover:scale-110 hover:shadow-xl hover:-translate-y-1"
                          >
                            <i
                              class="fas fa-trash text-sm group-hover/btn:animate-pulse"
                            ></i>
                          </button>
                          <button
                            class="icon group/btn p-2 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-xl shadow-lg transform transition-all duration-300 hover:scale-110 hover:shadow-xl hover:-translate-y-1"
                          >
                            <i
                              class="fas fa-check text-sm group-hover/btn:animate-pulse"
                            ></i>
                          </button>
                        </div>
                      </td>
                    </tr>
    */
  const tbody = document.querySelector("#task-list");
  // tr - table row --> td -->cell (table data)
  const tr = tbody.insertRow();
  tr.classList =
    "group hover:bg-gradient-to-r hover:from-blue-50 hover:via-purple-50 hover:to-pink-50 transition-all duration-300 transform hover:scale-[1.02] hover:shadow-lg";
  for (let key in taskObject) {
    const td = tr.insertCell();
    td.classList =
      "px-6 py-5 border-r border-gray-200 font-bold text-gray-800 group-hover:text-blue-600 transition-colors duration-300";
    td.innerText = taskObject[key];
  }
  const cell = tr.insertCell();
  const div = document.createElement("div");
  div.className = "flex justify-center space-x-3";
  cell.className = "px-6 py-5 text-center";

  const editButton = document.createElement("button");
  editButton.className =
    "icon group/btn p-2 bg-gradient-to-r from-blue-500 to-indigo-500 text-white rounded-xl shadow-lg transform transition-all duration-300 hover:scale-110 hover:shadow-xl hover:-translate-y-1";
  const editTag = document.createElement("i");
  editTag.className = "fas fa-pen text-sm group-hover/btn:animate-pulse";
  editButton.appendChild(editTag);

  const trashButton = document.createElement("button");
  trashButton.className =
    "icon group/btn p-2 bg-gradient-to-r from-red-500 to-pink-500 text-white rounded-xl shadow-lg transform transition-all duration-300 hover:scale-110 hover:shadow-xl hover:-translate-y-1";
  const trashTag = document.createElement("i");
  trashTag.className = "fas fa-trash text-sm group-hover/btn:animate-pulse";
  trashButton.appendChild(trashTag);

  const checkButton = document.createElement("button");
  checkButton.className =
    "icon group/btn p-2 bg-gradient-to-r from-green-500 to-emarald-500 text-white rounded-xl shadow-lg transform transition-all duration-300 hover:scale-110 hover:shadow-xl hover:-translate-y-1";
  const checkTag = document.createElement("i");
  checkTag.className = "fas fa-check text-sm group-hover/btn:animate-pulse";
  checkButton.appendChild(checkTag);

  editButton.onclick = edit;
  trashButton.onclick = toggleTask;
  div.appendChild(editButton);
  div.appendChild(trashButton);
  div.appendChild(checkButton);

  cell.appendChild(div);

  //cell.innerText = 'delete edit';
  //cell.innerHTML = ' <i class="fa-solid fa-trash"></i> <i class="fa-solid fa-pen"></i>';
}
function createIcon(className, fn) {
  const iTag = document.createElement("i");
  iTag.className = `icon fa-solid ${className}`;
  iTag.addEventListener("click", fn);
  return iTag;
}

function toggleTask() {
  console.log("Toggle Task Call ");
}
function edit() {
  console.log("Edit Task Call ");
}
// <i class="fa-solid fa-trash"></i> <i class="fa-solid fa-pen"></i>
function readFields() {
  const fields = ["id", "name", "desc"];
  const taskObject = {}; // Object Literal
  for (let field of fields) {
    taskObject[field] = document.querySelector(`#${field}`).value;
  }
  return taskObject;

  //console.log('Task object ', taskObject);
  // const id = document.querySelector('#id').value;
  // const name = document.querySelector('#name').value;
  // const desc = document.querySelector('#desc').value;
  //console.log('All Field data is ', id, name, desc);
}
