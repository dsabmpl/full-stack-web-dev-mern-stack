import App from "./App";
import { createRoot } from "react-dom/client";
const div = document.querySelector("#root");
createRoot(div).render(<App />);
// VDOM --> DOM Mapping via ReactDOM
