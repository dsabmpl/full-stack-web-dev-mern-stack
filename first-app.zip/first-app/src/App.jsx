// Write First component (root component)
// Arrow Function - ES6 Pure Function + Short Hand Function + no function constructor + no arguments
import React, { useState } from "react";
import "./App.css";
const App = () => {
  // let counter = 0;
  const [counter, setCounter] = useState(0);

  const fruitsData = [
    {
      isAdded: false,
      name: "Orange",
      price: 1000,
      qty: 10,
      url: "https://www.bbassets.com/media/uploads/p/m/40083737_8-fresho-mosambi-premium.jpg",
    },
    {
      isAdded: false,
      name: "Apple",
      price: 20300,
      qty: 20,
      url: "https://www.bbassets.com/media/uploads/p/m/40319277_1-fresho-baby-apple-organically-grown.jpg?tr=w-154,q-80",
    },
    {
      isAdded: false,
      name: "Banana",
      price: 40,
      qty: 1,
      url: "https://www.bbassets.com/media/uploads/p/m/40023475_7-fresho-banana-robusta-organically-grown.jpg",
    },
  ];
  const [fruits, setFruits] = useState(fruitsData);
  const title = "Hi React JS";
  const time = 18;
  const greet = () => {
    if (time < 12) {
      return <p>Good Morning </p>;
    } else if (time >= 12 && time <= 16) {
      return <p>Good Afternoon</p>;
    } else {
      return <p>Good Evening</p>;
    }
  };
  const plus = (name) => {
    console.log("Current Fruit name is ", name);
    const fruit = fruits.find((fruit) => fruit.name === name);
    fruit.isAdded = true;
    setFruits([...fruits]);
    console.log("Find it ", fruit);
    setCounter(counter + 1); // async
    console.log("Counter is ", counter);
  };
  return (
    <div>
      <h1 style={{ color: "green" }}>{title}</h1>
      <h2>Brain Mentors</h2>
      {time < 12 ? <p>Good Morning</p> : <p>Good Day</p>}
      <div>{greet()}</div>
      <div>
        <p>Fruits are </p>
        <p>total items in cart {counter}</p>
        <ul>
          {fruits.map((fruit, index) => (
            <li key={index}>
              {fruit.name} &#8377;{fruit.price.toLocaleString("hi")}
              &nbsp;&nbsp;&nbsp;&nbsp;{fruit.qty}
              <img
                style={{ width: "100px", height: "100px" }}
                src={fruit.url}
              />
              <button
                onClick={() => {
                  plus(fruit.name);
                }}
              >
                {!fruit.isAdded ? "Add to Cart" : "Added in Cart"}
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
  // const h1 = React.createElement(
  //   "h1",
  //   { style: { color: "red", backgroundColor: "cyan" } },
  //   title
  // );
  // const h2 = React.createElement("h2", null, "Brain Mentors");
  // //return h1, h2;
  // return React.createElement("div", null, h1, h2);
};
export default App;
