// Structure of object (task) - id, name, desc

class Task{
    constructor(id, name, desc){
        this.id = id;
        this.name = name;
        this.desc = desc;
    }
}