// Service - Contains Business Logic eg. CRUD Logic
const ToDoService ={
    addTask(){

    },
    deleteTask(){

    },
    searchTask(){

    },
    updateTask(){

    },
    countMarkTask(){

    },
    countUnMarkTask(){

    },
    sortTask(){

    }
}