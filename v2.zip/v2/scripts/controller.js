// Glue b/w View and Model / Service
window.addEventListener('load', bindEvents);
function bindEvents(){
    document.querySelector('#add').addEventListener('click', addNewTask);
}
function addNewTask(){
    // read Fields
    readFields();
}
function readFields(){
    const id = document.querySelector('#id').value;
    const name = document.querySelector('#name').value;
    const desc = document.querySelector('#desc').value;
    console.log('All Field data is ', id, name, desc);
}