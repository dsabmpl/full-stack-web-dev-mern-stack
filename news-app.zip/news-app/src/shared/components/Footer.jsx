import * as Separator from "@radix-ui/react-separator";
import { Gem } from "lucide-react";
export const Footer = () => {
  return (
    <footer>
      <div style={{ textAlign: "center" }}>
        <Separator.Root style={{ height: "1px", backgroundColor: "black" }} />
        <p>
          <Gem /> Powered by Brain Mentors
        </p>
      </div>
    </footer>
  );
};
