import { Heading } from "@radix-ui/themes";
import { Rocket } from "lucide-react";
export const Header = () => {
  return (
    <header>
      <div style={{ padding: "20px", textAlign: "center" }}>
        <Heading
          style={{
            color: "red",
            background: "linear-gradient(140deg, yellow, green 100%)",
          }}
        >
          <Rocket />
          News App
        </Heading>
      </div>
    </header>
  );
};
