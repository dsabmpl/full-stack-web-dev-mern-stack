import axios from 'axios';

export const getData = (URL)=>{
    return axios.get(URL);
}