import { useEffect, useState } from "react";
import { Footer } from "../../../shared/components/Footer";
import { Header } from "../../../shared/components/Header";
import { getAllNews } from "../api/news-api";
import { LoaderIcon } from "lucide-react";

export const Home = () => {
  const [articles, setArticles] = useState([]);
  const getNewsData = async () => {
    const articles = await getAllNews();
    setArticles(articles);
  };
  // Component Life Cycle
  useEffect(() => {
    // call the backend api
    getNewsData();
  }, []);
  return (
    <div>
      <Header />
      <main>
        <div
          style={{
            minHeight: "100vh",
            backgroundColor: "black",
            color: "white",
            fontSize: "20px",
          }}
        >
          {articles.length == 0 ? <LoaderIcon /> : articles.length}
          {articles.map((article, index) => {
            return (
              <div>
                <img
                  style={{ width: "75%", height: "400px" }}
                  src={article.urlToImage}
                />
                <h2>{article.title}</h2>
                <h3>{article.description}</h3>
                <a href={article.url} target="_blank">
                  Read More...
                </a>
              </div>
            );
          })}
        </div>
      </main>
      <Footer />
    </div>
  );
};
