import { getData } from "../../../shared/services/api-client"

export const getAllNews = async ()=>{
    console.log('Env Data read ', import.meta.env.VITE_NEWS_URL);
    const response = await getData(import.meta.env.VITE_NEWS_URL);
    console.log('All news data is ', response.data.articles);
    return  response.data.articles;
}