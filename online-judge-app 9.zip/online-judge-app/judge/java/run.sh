#!/bin/sh
set -e
cd /workspace
mkdir -p out

if ! javac Main.java 2> compile_err.txt; then
  echo '{"status":"COMPILE_ERROR"}' > report.jsonl
  exit 0
fi

> report.jsonl

while IFS="$(printf '\t')" read -r idx tsec bin_in bin_exp; do
  # skip empty lines (in case there are any)
  [ -z "$idx" ] && continue

  # Decode base64 -> real input / expected output
  printf '%s' "$bin_in"  | base64 -d > in.txt
  printf '%s' "$bin_exp" | base64 -d > exp.txt

  # Run student's program with a time limit.
  # timeout <seconds> java Main < in.txt
  #   stdout -> out/case-<idx>.txt
  #   stderr -> out/case-<idx>-err.txt
  if timeout "${tsec}s" java Main < in.txt \
      > "out/case-${idx}.txt" 2> "out/case-${idx}-err.txt"; then
    # Program finished normally
    echo "{\"idx\":${idx},\"status\":\"OK\"}" >> report.jsonl
  else
    # Program crashed or time limit exceeded
    echo "{\"idx\":${idx},\"status\":\"RUNTIME_ERROR_OR_TLE\"}" >> report.jsonl
  fi
done < cases.txt