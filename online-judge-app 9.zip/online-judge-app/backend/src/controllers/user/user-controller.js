import { addUser, findUserByEmail } from "../../services/user-service.js";
import { comparePwd } from "../../utils/services/encryption.js";
import { generateToken } from "../../utils/services/token.js";

export const doRegister = async (request, response)=>{
      const userInfo = request.body;

      try{
            const userDoc = await addUser(userInfo);
            console.log(userDoc);
            if(userDoc && userDoc._id){
                  response.status(200).json({message: 'User Added SuccessFully'});
            }
            else{
                   response.status(500).json({message: 'User Added Failed...'});
            }
      }
      catch(err){
            response.status(500).json({message: 'User Added Failed...'});
            console.log(err);
      }

      //console.log('UserInfo is ', userInfo);
      //response.send('Register....')
      //response.status(200).json({message:'Register SuccessFully'});
}
export const doLogin = async (request, response)=>{
      try{
     const {email, password} =  request.body;
     console.log('Email is ',email);
     console.log('Pwd is ', password);
     const user = await findUserByEmail(email);
     if(!user){
      return response.status(401).json({message:'Invalid Email or Password...'});
     }
     console.log('DB Pwd ', user.password, ' Plain PWd ', password);
     const isMatched = await comparePwd(user.password, password);
     console.log('IS matched ', isMatched);
     if(!isMatched){
      return response.status(401).json({message:'Invalid Email or Password'})
     }
     // User Login SuccessFully , then do generate token
     const token = generateToken({email:user.email, role : user.role})
     const userInfo = {
            name : user.name, 
            email : user.email, 
            role : user.role,
            rating : user.rating,
            solvedCount : user.solvedCount

     }
    response.status(200).json({message:'Login SuccessFully ', user: userInfo, token});
}
catch(err){
      console.log('Login Error ', err);
      return response.status(500).json({message:'Something Went Wrong...'});
}
}