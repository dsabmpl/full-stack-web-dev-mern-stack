import {z} from 'zod';
export const judgeRunSchema = z.object({
    problemId : z.string({required_error :' Problem Id is required'}).trim(),
    language : z.string({required_error :'Language is Required'}).trim().toLowerCase()
    .refine(lang=>["javascript", "cpp", "java", "python"].
        includes(lang), {message:"UnSupported Language"}),
        code: z.string({required_error:'Code is Required'}).min(1, "Code cannot be Empty")
});

export const judgeSubmitSchema = judgeRunSchema;