import { verifyToken } from "../services/token.js";

export const authenticate = (request, response, next)=>{
    try{
    const headerValue = request.headers.authorization || request.headers.Authorization;
    console.log('Header Value is ', headerValue);
    const decoded=verifyToken(headerValue);
    if(!decoded){
        return response.status(401).json({message : 'UnAuthorized User'});
    }
    request.userInfo = decoded;
    next();
    }
    catch(err){
        console.error('Auth Middleware Failed ', err);
        return response.status(500).json({message:'Something went wrong...'});
    }
}