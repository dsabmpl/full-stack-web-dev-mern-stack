export const Error404 = (request, response, next)=>{
    response.status(404).json({message : 'OOPS U Type Something Wrong...'});
}