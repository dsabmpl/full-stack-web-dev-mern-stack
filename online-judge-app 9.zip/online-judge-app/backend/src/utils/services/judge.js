// src/utils/services/judge.js
// --------------------------------------------------------------------
// Java + Docker judge helper
// --------------------------------------------------------------------
// 1. Create a temp folder
// 2. Write Main.java + cases.txt
// 3. Run Docker image: brain/java-runner:1.0
// 4. Read outputs, build summary + per-case verdict
// --------------------------------------------------------------------

import { promises as fs } from "fs";
import os from "os";
import path from "path";
import { exec } from "child_process";

const sh = (cmd, opts = {}) =>
  new Promise((res, rej) =>
    exec(cmd, opts, (err, stdout, stderr) =>
      err ? rej({ err, stdout, stderr }) : res({ stdout, stderr })
    )
  );

// normalize outputs so stray spaces/newlines don’t break answers
const normalize = (s) =>
  (s || "")
    .replace(/\r\n/g, "\n")
    .replace(/\r/g, "\n")
    .trim()
    .replace(/[ \t]+/g, " ")
    .replace(/\n{2,}/g, "\n");

// core function: compile once, run many
export async function judgeJava({ source, testcases, timeLimitMs = 2000 }) {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), "judge-"));
  try {
    // 1) write Main.java
    await fs.writeFile(path.join(dir, "Main.java"), source, "utf8");

    // 2) write cases.txt (tab-separated, with base64 to keep inputs clean)
    const tsec = Math.ceil(timeLimitMs / 1000);
    const toB64 = (s) => Buffer.from(s ?? "").toString("base64");
    const lines =
      testcases
        .map(
          (tc, i) =>
            `${i}\t${tsec}\t${toB64(tc.input)}\t${toB64(tc.expected)}`
        )
        .join("\n") + "\n"; // ensure trailing newline
    await fs.writeFile(path.join(dir, "cases.txt"), lines, "utf8");

    // 3) run ONE container (no network, CPU/RAM limits)
    const cmd = [
      "docker run --rm",
      "--cpus=0.5",
      "--memory=256m",
      "--pids-limit=64",
      "--network=none",
      "--security-opt=no-new-privileges",
      "--read-only",
      "-v",
      `${dir}:/workspace:rw`,
      "brain/java-runner:1.0",
    ].join(" ");
    await sh(cmd);

    // 4) read artifacts
    const reportText = await safeRead(path.join(dir, "report.jsonl"));
    const compileErr = await safeRead(path.join(dir, "compile_err.txt"));
    const events = reportText
      .trim()
      .split("\n")
      .filter(Boolean)
      .map((l) => {
        try {
          return JSON.parse(l);
        } catch {
          return {};
        }
      });

    // compile error?
    if (events[0]?.status === "COMPILE_ERROR") {
      return {
        summary: { total: testcases.length, passed: 0, allPassed: false },
        cases: testcases.map((_, idx) => ({
          idx,
          verdict: "CE",
          timeMs: 0,
          stdout: "",
          compileErr,
          runtimeErr: "",
        })),
      };
    }

    // build per-case verdicts
    const results = [];
    for (let i = 0; i < testcases.length; i++) {
      const out = await safeRead(path.join(dir, `out/case-${i}.txt`));
      const err = await safeRead(path.join(dir, `out/case-${i}-err.txt`));
      const ev = events.find((e) => e.idx === i);

      if (ev?.status === "RUNTIME_ERROR_OR_TLE") {
        results.push({
          idx: i,
          verdict: "RE",
          timeMs: 0,
          stdout: "",
          compileErr: "",
          runtimeErr: err,
        });
      } else {
        const pass = normalize(out) === normalize(testcases[i].expected);
        results.push({
          idx: i,
          verdict: pass ? "PASSED" : "WA",
          timeMs: 0,
          stdout: out,
          compileErr: "",
          runtimeErr: err,
        });
      }
    }

    const passed = results.filter((r) => r.verdict === "PASSED").length;
    return {
      summary: { total: results.length, passed, allPassed: passed === results.length },
      cases: results,
    };
  } finally {
    await fs.rm(dir, { recursive: true, force: true }).catch(() => {});
  }
}

async function safeRead(p) {
  try {
    return await fs.readFile(p, "utf8");
  } catch {
    return "";
  }
}

// demo if you run: node src/utils/services/judge.js
// (ESM: make sure "type": "module" in package.json)
if (import.meta.url === `file://${process.argv[1]}`) {
  (async () => {
    const source = `
public class Main {
  public static void main(String[] args){
    java.util.Scanner sc=new java.util.Scanner(System.in);
    long a=sc.nextLong(), b=sc.nextLong();
    System.out.println(a+b);
  }
}`;
    const testcases = [
      { input: "2 3\n", expected: "5\n" },
      { input: "10 20\n", expected: "30\n" },
    ];
    const verdict = await judgeJava({ source, testcases, timeLimitMs: 2000 });
    console.log(JSON.stringify(verdict, null, 2));
  })();
}