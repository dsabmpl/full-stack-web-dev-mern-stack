import { UserModel } from "../models/user-model.js"
import { encrypt } from "../utils/services/encryption.js";

export const addUser =  async (userInfo)=>{
    // const document = await UserModel.create(userInfo);
    // return document;
    userInfo.password = await encrypt(userInfo.password);
    return UserModel.create(userInfo);
}

export const findUserByEmail = (email)=>{
    return UserModel.findOne({email}).exec();
}