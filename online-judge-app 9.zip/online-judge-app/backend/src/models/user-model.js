import mongoose, { mongo } from 'mongoose';
const nameRegExpression = /^[A-Za-z]{2,25}$/
const userSchema = new mongoose.Schema({
    name: {
        type:String, required:[true, 'Name is Required'],
        validate : {
            validator : value => nameRegExpression.test(value),
            message :' Name must be Character and B/w 2 to 25 chars'
        }
    },
    email : {
        type: String, 
        required: [true, 'Email is Required'],
        unique: true,
        lowercase: true,
        trim: true,
    },
    password: {
        type: String, 
        required : [true, 'Password is Required'],
        minLength : [8, 'Password Min Length is 8 Chars'],
        maxLength : [100, 'Password in 100 chars Long Maximum']
    },
    role : {
        type : String ,
        enum: ["student", "teacher"],
        default : "student",
        required : true
    },
    rating : {type : Number , default:0},
    solvedCount : {type : Number, default : 0}
}, {timestamps: true})
export const UserModel = mongoose.model('users' , userSchema);