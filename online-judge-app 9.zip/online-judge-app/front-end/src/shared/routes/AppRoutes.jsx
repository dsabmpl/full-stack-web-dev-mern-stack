import { Route, Routes } from "react-router-dom";
import { Login } from "../../modules/user/pages/Login";
import { Register } from "../../modules/user/pages/Register";
import { Home } from "../../modules/home/pages/Home";
import { StudentDashboard } from "../../modules/dashboard/pages/StudentDashboard";
import { TeacherDashboard } from "../../modules/dashboard/pages/TeacherDashboard";
import { ProblemSolve } from "../../modules/questions/pages/ProblemSolve";

export const AppRoutes = () => {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="login" element={<Login />} />
      <Route path="register" element={<Register />} />
      {/* DashBoard Routes */}
      <Route path="dashboard/student" element={<StudentDashboard />} />
      <Route path="dashboard/teacher" element={<TeacherDashboard />} />
      <Route path="problem" element={<ProblemSolve />} />
    </Routes>
  );
};
