import { useState } from "react"
import { judgeApi } from "../api/problem-api";

export const useProblemExecutor = ()=>{
    const [code, setCode] = useState(`class Solution{ int add(int x, int y){}}`);
    const [result, setResult] = useState(null);
    const [error, setError] = useState("");
    const runCode = async (problem)=>{
        try{
            const payLoad = {
                problemId:"1001",
                language : "java",
                code ,
                testcases : problem.sampleTests || []
            };
            const data = await judgeApi.run(payLoad);
            console.log('Data is :::::: ', data);
            setResult(data);
        }
        catch(err){
            console.log('Code run Fails ' , err);
            setError(err.response?.data?.message || "Code Run Fails ");
        }
    }

    const submitCode = async (problem)=>{
         try{
            const payLoad = {
                language : "java",
                code ,
                testcases : problem.hiddenTests || []
            };
            const data = await judgeApi.submit(payLoad);
            setResult(data);
        }
        catch(err){
            console.log('Code run Fails ' , err);
            setError(err.response?.data?.message || "Code Submit Fails ");
        }
    }
    return {code , setCode, result, error, runCode, submitCode};

}